package net.sweenus.simplyskills.util;

import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

public class SimplySkillsPreInit implements PreLaunchEntrypoint {

    @Override
    public void onPreLaunch() {
        /*
        try {
            FileCopier.copyFileToConfigDirectory();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
         */

    }


}
